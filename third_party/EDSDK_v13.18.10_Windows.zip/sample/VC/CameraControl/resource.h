//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CameraControl.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDS_ABOUTBOX                    101
#define IDD_SAMPLE_DIALOG               102
#define IDD_CAMERACONTROL_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON1                     1000
#define IDC_BUTTON16                    1001
#define IDC_BUTTON19                    1002
#define IDC_EDIT1                       1005
#define IDC_PROGRESS1                   1006
#define IDC_COMBO1                      1007
#define IDC_COMBO2                      1008
#define IDC_COMBO3                      1009
#define IDC_COMBO4                      1010
#define IDC_COMBO5                      1011
#define IDC_COMBO6                      1012
#define IDC_BUTTON2                     1013
#define IDC_BUTTON3                     1014
#define IDC_BUTTON4                     1015
#define IDC_BUTTON5                     1016
#define IDC_BUTTON6                     1017
#define IDC_BUTTON7                     1018
#define IDC_BUTTON8                     1019
#define IDC_BUTTON9                     1020
#define IDC_COMBO7                      1021
#define IDC_PICT                        1022
#define IDC_BUTTON10                    1023
#define IDC_BUTTON11                    1024
#define IDC_BUTTON12                    1025
#define IDC_BUTTON13                    1026
#define IDC_BUTTON14                    1027
#define IDC_BUTTON15                    1028
#define IDC_COMBO8                      1029
#define IDC_BUTTON17                    1030
#define IDC_BUTTON18                    1031
#define IDC_BUTTON20                    1031
#define IDC_BUTTON21                    1032
#define IDC_BUTTON22                    1033

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

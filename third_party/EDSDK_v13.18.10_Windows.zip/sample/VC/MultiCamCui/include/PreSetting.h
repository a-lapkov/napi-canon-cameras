#include <vector>
#include "EDSDKTypes.h"
#include "CameraModel.h"

EdsError PreSetting(std::vector<CameraModel *> _model);
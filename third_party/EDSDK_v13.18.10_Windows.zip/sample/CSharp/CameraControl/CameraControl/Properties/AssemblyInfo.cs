﻿using System.Reflection;
using System.Runtime.InteropServices;


[assembly: AssemblyTitle("CameraControl")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("CANON INC.")]
[assembly: AssemblyProduct("CameraControl")]
[assembly: AssemblyCopyright("Copyright (C) CANON INC. 2018 All Rights Reserved")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]


[assembly: ComVisible(false)]


[assembly: Guid("ab832dd5-e825-48bc-a254-60af341ee979")]


[assembly: AssemblyVersion("1.0.1.100")]
[assembly: AssemblyFileVersion("1.0.1.100")]
